package dto;

public class imgDto {
	private String link;
	
	public void Imagedto() {
		
	}
	
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}

	@Override
	public String toString() {
		return  "link=" + link + "]";
	}
}
