package dto;

public class GoodsPaleteDto {
	Integer g_num;
	byte[] imgPalete;
}
